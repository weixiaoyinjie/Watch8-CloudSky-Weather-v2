# 云端天气 · Watch8 v2 三行首屏版

基于用户上传的 `CloudSky-Weather-Watch8-v1-OneUpload.zip` 源码修改。保留原包名 `com.cloudsky.weather.watch`，作为原安装版本的更新（`versionCode` 2）。

## 首屏 / 下方第二屏

- **第一行：当天实时天气**。城市、天气图标、当前温度、天气描述、刷新状态。
- **第二行：未来几个小时**。小时在上、天气图标在中、温度和降雨概率在下。横向滑动可看完 24 小时，**不用竖向翻动**。
- **第三行：未来几天**。日期在上、天气图标在中、高低温和降雨概率在下。横向滑动可看 7 天。
- **向上滑动，进入下方第二屏**：手动刷新、手表定位、全球城市搜索，以及体感温度/湿度/风速/降水数据和天气源署名。
- 全球城市搜索仍会打开独立的输入结果页面，选择城市后自动回到三行天气首页。

保持原有 Open-Meteo 接口、24 小时和 7 天数据、缓存、定位权限、全球城市搜索、纯黑省电背景；无需配套手机 App。针对圆形屏幕采用紧凑字号与安全边距。

## GitHub Actions 一次上传编译

1. 建议建**新仓库** `Watch8-CloudSky-Weather-v2`：https://github.com/new
2. 上传完整的 `CloudSky-Weather-Watch8-v2-OneUpload.zip` 到仓库根目录，不解压。请不要同仓库保留旧 v1 ZIP。
3. 在仓库中创建或替换 `.github/workflows/build-apk.yml`，内容使用单独提供的 `build-apk.yml` 文件。
4. GitHub 仓库 Actions → **Build Watch8 Weather v2 Three-Row APK** → **Run workflow**（如果 push 已自动触发，则等其执行）。
5. 成功后在该次 Actions 底部的 Artifacts 下载 `CloudSky-Weather-Watch8-v2-APK`，解压得到 `CloudSky-Weather-Watch8-v2.apk`。
6. 通过 Wear Installer 2 安装到 Galaxy Watch8；包名与旧版相同，旧版是原版 debug 签名时需先卸载再安装新包（安装新包是否可直接覆盖取决于签名一致性）。

要求：Java 17 / Gradle 8.11.1 / AGP 8.9.2 / Android SDK 35。ZIP 内含全工程与 workflow；因为上传的是整包 ZIP，必须额外放置 workflow 文件在 GitHub 项目目录中，GitHub 才能识别和编译。

**验证状态**：已完成源码改版、结构检查和编译脚本更新。本环境未安装 Android SDK/Gradle，无法在本地生成或实测 APK；请以 GitHub Actions 成功产物为准。实际设备上检查圆屏是否完全显示三行。
