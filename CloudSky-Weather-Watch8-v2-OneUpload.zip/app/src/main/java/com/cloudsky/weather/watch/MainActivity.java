package com.cloudsky.weather.watch;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int NAVY = Color.WHITE;
    private static final int MUTED = Color.rgb(159, 174, 194);
    private static final int BLUE = Color.rgb(112, 182, 255);
    private static final int WHITE = Color.WHITE;
    private static final int REQUEST_LOCATION = 61;
    private static final String PREFS = "cloudsky_weather";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private double latitude = -34.6037;
    private double longitude = -58.3816;
    private String city = "Buenos Aires, Argentina";
    private boolean destroyed = false;
    private int requestSequence = 0;

    private TextView cityView;
    private TextView statusView;
    private TextView weatherEmoji;
    private TextView tempView;
    private TextView weatherView;
    private TextView updateView;
    private TextView[] detailValue = new TextView[4];
    private LinearLayout hourRow;
    private LinearLayout daysList;
    private LinearLayout hero;
    private EditText cityInput;
    private TextView searchStatus;
    private LinearLayout searchResults;
    private boolean searchPage = false;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private boolean awaitingLocation = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        latitude = Double.longBitsToDouble(prefs.getLong("lat", Double.doubleToRawLongBits(latitude)));
        longitude = Double.longBitsToDouble(prefs.getLong("lon", Double.doubleToRawLongBits(longitude)));
        city = prefs.getString("city", city);
        buildScreen();
        String cached = prefs.getString("cache", "");
        if (!cached.isEmpty()) {
            try {
                render(new JSONObject(cached));
                statusView.setText("上次保存的数据 · 正在检查更新");
            } catch (Exception ignored) { }
        }
        long savedAt = prefs.getLong("cached_at", 0L);
        if (cached.isEmpty() || System.currentTimeMillis() - savedAt > 10 * 60 * 1000L) {
            loadWeather();
        } else {
            statusView.setText("刚刚更新 · 点击刷新按钮");
        }
    }


    // The first viewport is a compact, glanceable three-row forecast.
    // Swipe up to scroll down into the second (controls/details) page.
    // Hourly and daily strips independently scroll horizontally, retaining all forecasts.
    private void buildScreen() {
        searchPage = false;
        boolean roundScreen = getResources().getConfiguration().isScreenRound();
        float density = getResources().getDisplayMetrics().density;
        int screenHeight = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        boolean compact = screenHeight < 285;
        int side = roundScreen ? (compact ? 23 : 26) : 14;
        int top = roundScreen ? (compact ? 9 : 20) : 12;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.BLACK);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(side), dp(top), dp(side), 0);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(body);
        setContentView(scroll);

        // PAGE 1: One full watch screen, no buttons or settings.
        LinearLayout firstPage = new LinearLayout(this);
        firstPage.setOrientation(LinearLayout.VERTICAL);
        firstPage.setGravity(Gravity.CENTER_HORIZONTAL);
        firstPage.setMinimumHeight(dp(Math.max(180, screenHeight - top)));
        body.addView(firstPage, new LinearLayout.LayoutParams(-1, -2));

        hero = new LinearLayout(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(4), dp(compact ? 2 : 5), dp(4), dp(compact ? 2 : 5));
        hero.setBackground(heroBackground(true, 1));
        firstPage.addView(hero, new LinearLayout.LayoutParams(-1, -2));

        cityView = text(city, compact ? 11 : 12, WHITE, true);
        cityView.setGravity(Gravity.CENTER);
        cityView.setSingleLine(true);
        cityView.setEllipsize(TextUtils.TruncateAt.END);
        hero.addView(cityView, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout nowRow = new LinearLayout(this);
        nowRow.setGravity(Gravity.CENTER);
        nowRow.setOrientation(LinearLayout.HORIZONTAL);
        hero.addView(nowRow, new LinearLayout.LayoutParams(-1, dp(compact ? 30 : 41)));
        weatherEmoji = text("🌤️", compact ? 22 : 29, WHITE, false);
        weatherEmoji.setGravity(Gravity.CENTER);
        nowRow.addView(weatherEmoji, new LinearLayout.LayoutParams(dp(compact ? 35 : 42), -1));
        tempView = text("--°", compact ? 26 : 34, WHITE, true);
        tempView.setGravity(Gravity.CENTER);
        tempView.setSingleLine(true);
        nowRow.addView(tempView);
        weatherView = text("加载中", compact ? 10 : 11, WHITE, false);
        weatherView.setGravity(Gravity.CENTER);
        weatherView.setSingleLine(true);
        weatherView.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams wvp = new LinearLayout.LayoutParams(-2, -2);
        wvp.leftMargin = dp(5);
        nowRow.addView(weatherView, wvp);

        updateView = text("", compact ? 8 : 9, MUTED, false);
        updateView.setGravity(Gravity.CENTER);
        updateView.setSingleLine(true);
        // Keep update timestamp on the next page to save the first-screen height.
        statusView = text("正在获取最新预报…", compact ? 8 : 9, MUTED, false);
        statusView.setGravity(Gravity.CENTER);
        statusView.setSingleLine(true);
        statusView.setEllipsize(TextUtils.TruncateAt.END);
        hero.addView(statusView, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout hoursSection = compactSection(firstPage, "未来几小时 · 左右滑动", compact);
        HorizontalScrollView hoursScroll = new HorizontalScrollView(this);
        hoursScroll.setHorizontalScrollBarEnabled(false);
        hoursScroll.setFillViewport(false);
        hourRow = new LinearLayout(this);
        hourRow.setOrientation(LinearLayout.HORIZONTAL);
        hoursScroll.addView(hourRow, new HorizontalScrollView.LayoutParams(-2, -2));
        hoursSection.addView(hoursScroll, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout dailySection = compactSection(firstPage, "未来几天 · 左右滑动", compact);
        HorizontalScrollView daysScroll = new HorizontalScrollView(this);
        daysScroll.setHorizontalScrollBarEnabled(false);
        daysScroll.setFillViewport(false);
        daysList = new LinearLayout(this);
        daysList.setOrientation(LinearLayout.HORIZONTAL);
        daysScroll.addView(daysList, new HorizontalScrollView.LayoutParams(-2, -2));
        dailySection.addView(daysScroll, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = text("上滑：刷新 · 定位 · 城市与详情  ↓", compact ? 8 : 9, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintP = new LinearLayout.LayoutParams(-1, -2);
        hintP.topMargin = dp(compact ? 1 : 6);
        firstPage.addView(hint, hintP);

        // PAGE 2: Accessed by a vertical scroll from the home forecast.
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.setGravity(Gravity.CENTER_HORIZONTAL);
        tools.setPadding(dp(3), dp(10), dp(3), dp(20));
        tools.setMinimumHeight(dp(Math.max(185, screenHeight - top)));
        body.addView(tools, new LinearLayout.LayoutParams(-1, -2));
        TextView settingsTitle = text("天气设置与详情", 16, WHITE, true);
        settingsTitle.setGravity(Gravity.CENTER);
        tools.addView(settingsTitle, new LinearLayout.LayoutParams(-1, dp(26)));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ctlP = new LinearLayout.LayoutParams(-1, -2);
        ctlP.topMargin = dp(9);
        tools.addView(controls, ctlP);
        TextView refresh = actionChip("↻  刷新");
        refresh.setTextSize(12);
        refresh.setContentDescription("刷新天气");
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, dp(43), 1);
        rp.rightMargin = dp(6);
        controls.addView(refresh, rp);
        refresh.setOnClickListener(v -> loadWeather());
        TextView locate = actionChip("⌖  定位");
        locate.setTextSize(12);
        locate.setContentDescription("定位当前城市");
        controls.addView(locate, new LinearLayout.LayoutParams(0, dp(43), 1));
        locate.setOnClickListener(v -> locateMe());

        TextView search = actionChip("⌕  搜索全球城市");
        search.setTextSize(13);
        search.setBackground(round(0xFF1B314E, 16));
        LinearLayout.LayoutParams searchP = new LinearLayout.LayoutParams(-1, dp(44));
        searchP.topMargin = dp(9);
        tools.addView(search, searchP);
        search.setOnClickListener(v -> showSearchScreen());

        tools.addView(updateView, new LinearLayout.LayoutParams(-1, -2));
        TextView detailTitle = text("当前天气详细数据", 12, MUTED, true);
        detailTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2);
        titleP.topMargin = dp(13);
        titleP.bottomMargin = dp(6);
        tools.addView(detailTitle, titleP);
        LinearLayout detailGrid = new LinearLayout(this);
        detailGrid.setOrientation(LinearLayout.VERTICAL);
        tools.addView(detailGrid, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row1 = new LinearLayout(this);
        LinearLayout row2 = new LinearLayout(this);
        detailGrid.addView(row1);
        LinearLayout.LayoutParams row2P = new LinearLayout.LayoutParams(-1, -2);
        row2P.topMargin = dp(6);
        detailGrid.addView(row2, row2P);
        addDetail(row1, 0, "体感");
        addDetail(row1, 1, "湿度");
        addDetail(row2, 2, "风速");
        addDetail(row2, 3, "降水");

        TextView footer = text("数据：Open-Meteo.com  ·  地名：GeoNames", 9, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(17);
        tools.addView(footer, fp);
        showSkeleton();
    }

    private LinearLayout compactSection(LinearLayout parent, String title, boolean compact) {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(dp(3), dp(compact ? 2 : 5), dp(3), dp(compact ? 2 : 5));
        section.setBackground(round(0xFF131A23, 13));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(compact ? 2 : 7);
        parent.addView(section, p);
        TextView heading = text(title, compact ? 10 : 11, WHITE, true);
        heading.setGravity(Gravity.CENTER);
        section.addView(heading, new LinearLayout.LayoutParams(-1, dp(compact ? 13 : 19)));
        return section;
    }

    private LinearLayout section(LinearLayout parent, String heading, String helper) {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(dp(10), dp(13), dp(10), dp(14));
        section.setBackground(round(0xFF11161F, 20));
        LinearLayout.LayoutParams sectionP = new LinearLayout.LayoutParams(-1, -2);
        sectionP.topMargin = dp(12);
        parent.addView(section, sectionP);
        TextView label = text(heading, 15, WHITE, true);
        label.setGravity(Gravity.CENTER);
        section.addView(label);
        TextView description = text(helper, 10, MUTED, false);
        description.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams helperP = new LinearLayout.LayoutParams(-1, -2);
        helperP.topMargin = dp(3);
        helperP.bottomMargin = dp(10);
        section.addView(description, helperP);
        return section;
    }

    private void addDetail(LinearLayout row, int index, String title) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(2), dp(9), dp(2), dp(8));
        tile.setBackground(round(0xFF222936, 12));
        LinearLayout.LayoutParams tileP = new LinearLayout.LayoutParams(0, -2, 1);
        if (index % 2 == 1) tileP.leftMargin = dp(6);
        row.addView(tile, tileP);
        TextView caption = text(title, 11, MUTED, false);
        caption.setGravity(Gravity.CENTER);
        tile.addView(caption);
        detailValue[index] = text("--", 13, WHITE, true);
        detailValue[index].setGravity(Gravity.CENTER);
        detailValue[index].setSingleLine(true);
        tile.addView(detailValue[index]);
    }

    private void showSearchScreen() {
        searchPage = true;
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        scroll.setPadding(dp(28), dp(30), dp(28), dp(30));
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(body);
        setContentView(scroll);
        TextView back = actionChip("‹  返回天气");
        back.setTextSize(14);
        body.addView(back, new LinearLayout.LayoutParams(-1, dp(46)));
        back.setOnClickListener(v -> returnHome());
        TextView heading = text("搜索全球城市", 19, WHITE, true);
        heading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(13);
        body.addView(heading, hp);
        TextView hint = text("支持中文 / English / Español", 11, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        body.addView(hint);
        cityInput = new EditText(this);
        cityInput.setSingleLine(true);
        cityInput.setTextSize(16);
        cityInput.setHint("输入城市名称");
        cityInput.setHintTextColor(MUTED);
        cityInput.setTextColor(WHITE);
        cityInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        cityInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        cityInput.setPadding(dp(12), 0, dp(12), 0);
        cityInput.setBackground(round(0xFF202735, 15));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(54));
        inputParams.topMargin = dp(13);
        body.addView(cityInput, inputParams);
        cityInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                searchCities();
                return true;
            }
            return false;
        });
        TextView go = actionChip("搜索城市");
        go.setTextSize(16);
        go.setBackground(round(0xFF18477D, 15));
        LinearLayout.LayoutParams goP = new LinearLayout.LayoutParams(-1, dp(48));
        goP.topMargin = dp(10);
        body.addView(go, goP);
        go.setOnClickListener(v -> searchCities());
        searchStatus = text("选择一个城市即可查看天气", 11, MUTED, false);
        searchStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusP = new LinearLayout.LayoutParams(-1, -2);
        statusP.topMargin = dp(11);
        body.addView(searchStatus, statusP);
        searchResults = new LinearLayout(this);
        searchResults.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams resultsP = new LinearLayout.LayoutParams(-1, -2);
        resultsP.topMargin = dp(6);
        body.addView(searchResults, resultsP);
    }

    private void setSearchStatus(String msg) {
        if (searchPage && searchStatus != null) searchStatus.setText(msg);
    }

    private void showSearchResults(String[] labels, JSONArray matches) {
        if (!searchPage || searchResults == null) return;
        searchResults.removeAllViews();
        for (int i = 0; i < labels.length; i++) {
            final int selectedIndex = i;
            TextView choice = text(labels[i], 13, WHITE, false);
            choice.setGravity(Gravity.CENTER);
            choice.setPadding(dp(6), dp(9), dp(6), dp(9));
            choice.setMinHeight(dp(52));
            choice.setBackground(round(0xFF1C2635, 13));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(7);
            searchResults.addView(choice, p);
            choice.setOnClickListener(v -> {
                JSONObject selected = matches.optJSONObject(selectedIndex);
                if (selected == null) return;
                latitude = selected.optDouble("latitude", latitude);
                longitude = selected.optDouble("longitude", longitude);
                city = labels[selectedIndex];
                prefs.edit().putLong("lat", Double.doubleToRawLongBits(latitude))
                        .putLong("lon", Double.doubleToRawLongBits(longitude))
                        .putString("city", city).remove("cache").remove("cached_at").apply();
                requestSequence++;
                buildScreen();
                clearCurrentWeather();
                loadWeather();
            });
        }
    }

    private void returnHome() {
        buildScreen();
        String cached = prefs.getString("cache", "");
        if (!cached.isEmpty()) {
            try {
                render(new JSONObject(cached));
                statusView.setText("上次保存的数据 · 点击刷新");
            } catch (Exception ignored) { loadWeather(); }
        } else {
            loadWeather();
        }
    }

    @Override public void onBackPressed() {
        if (searchPage) returnHome();
        else super.onBackPressed();
    }
    private void clearCurrentWeather() {
        tempView.setText("--°");
        weatherEmoji.setText("🌤️");
        weatherView.setText("正在加载当地天气");
        updateView.setText("");
        for (TextView value : detailValue) value.setText("--");
    }

    private void showSkeleton() {
        hourRow.removeAllViews();
        daysList.removeAllViews();
        hourRow.addView(text("正在获取小时预报…", 13, MUTED, false));
        daysList.addView(text("正在获取未来一周天气…", 13, MUTED, false));
    }


    private void searchCities() {
        if (!searchPage || cityInput == null) return;
        String query = cityInput.getText().toString().trim();
        if (query.length() < 2) {
            toast("请输入至少两个字符的城市名");
            return;
        }
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(cityInput.getWindowToken(), 0);
        cityInput.clearFocus();
        setSearchStatus("正在搜索城市…");
        searchResults.removeAllViews();
        io.execute(() -> {
            try {
                String address = "https://geocoding-api.open-meteo.com/v1/search?name="
                        + URLEncoder.encode(query, "UTF-8") + "&count=8&language=zh&format=json";
                JSONObject response = new JSONObject(httpGet(address));
                JSONArray places = response.optJSONArray("results");
                if (places == null || places.length() == 0) {
                    ui(() -> setSearchStatus("没有找到城市，请尝试英文或西语"));
                    return;
                }
                final JSONArray matches = places;
                String[] labels = new String[matches.length()];
                for (int i = 0; i < labels.length; i++) {
                    JSONObject p = matches.getJSONObject(i);
                    String admin = p.optString("admin1", "");
                    String country = p.optString("country", "");
                    labels[i] = p.optString("name") + (admin.isEmpty() ? "" : " · " + admin)
                            + (country.isEmpty() ? "" : " · " + country);
                }
                ui(() -> {
                    setSearchStatus("找到 " + labels.length + " 个匹配结果");
                    showSearchResults(labels, matches);
                });
            } catch (Exception e) {
                ui(() -> { setSearchStatus("城市搜索失败，请检查网络"); toast("搜索失败，请重试"); });
            }
        });
    }

    private void loadWeather() {
        final int myRequest = ++requestSequence;
        final double lat = latitude;
        final double lon = longitude;
        statusView.setText("正在更新天气…");
        io.execute(() -> {
            try {
                String url = "https://api.open-meteo.com/v1/forecast?latitude="
                        + String.format(Locale.US, "%.5f", lat)
                        + "&longitude=" + String.format(Locale.US, "%.5f", lon)
                        + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m"
                        + "&hourly=temperature_2m,precipitation_probability,weather_code"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset"
                        + "&forecast_days=7&timezone=auto";
                String json = httpGet(url);
                JSONObject response = new JSONObject(json);
                if (response.optBoolean("error", false)) throw new Exception(response.optString("reason"));
                response.getJSONObject("current");
                response.getJSONObject("hourly");
                response.getJSONObject("daily");
                ui(() -> {
                    if (myRequest != requestSequence) return;
                    try {
                        render(response);
                        String localTime = response.optJSONObject("current").optString("time", "");
                        statusView.setText("天气更新于 " + displayTime(localTime));
                        prefs.edit().putString("cache", json)
                                .putLong("cached_at", System.currentTimeMillis()).apply();
                    } catch (Exception e) {
                        statusView.setText("天气数据解析失败，请重试");
                    }
                });
            } catch (Exception e) {
                ui(() -> {
                    if (myRequest != requestSequence) return;
                    statusView.setText(prefs.contains("cache") ? "网络不可用 · 显示上次缓存" : "天气加载失败 · 请检查网络后刷新");
                    toast("天气请求失败，请检查网络");
                });
            }
        });
    }

    private void render(JSONObject response) throws Exception {
        JSONObject current = response.getJSONObject("current");
        int code = current.optInt("weather_code", 0);
        int isDay = current.optInt("is_day", 1);
        hero.setBackground(heroBackground(isDay == 1, code));
        cityView.setText(city);
        tempView.setText(roundTemperature(current.optDouble("temperature_2m", Double.NaN)) + "°");
        weatherEmoji.setText(emoji(code, isDay == 1));
        weatherView.setText(weatherName(code));
        updateView.setText("当地时间  " + displayTime(current.optString("time", "")));
        detailValue[0].setText(roundTemperature(current.optDouble("apparent_temperature", Double.NaN)) + " °C");
        detailValue[1].setText(whole(current.optDouble("relative_humidity_2m", Double.NaN)) + "%");
        detailValue[2].setText(whole(current.optDouble("wind_speed_10m", Double.NaN)) + " km/h");
        detailValue[3].setText(oneDecimal(current.optDouble("precipitation", Double.NaN)) + " mm");

        JSONObject hourly = response.getJSONObject("hourly");
        JSONArray times = hourly.getJSONArray("time");
        JSONArray temperatures = hourly.getJSONArray("temperature_2m");
        JSONArray chances = hourly.getJSONArray("precipitation_probability");
        JSONArray hourlyCodes = hourly.getJSONArray("weather_code");
        String currentHour = current.optString("time", "");
        if (currentHour.length() >= 13) currentHour = currentHour.substring(0, 13);
        int start = 0;
        for (int i = 0; i < times.length(); i++) {
            String hour = times.optString(i, "");
            if (hour.length() >= 13 && hour.substring(0, 13).compareTo(currentHour) >= 0) {
                start = i;
                break;
            }
        }
        hourRow.removeAllViews();
        boolean compact = getResources().getDisplayMetrics().heightPixels
                / getResources().getDisplayMetrics().density < 285;
        int count = Math.min(24, times.length() - start);
        for (int i = 0; i < count; i++) {
            int j = i + start;
            String at = times.optString(j, "");
            String hour = at.length() >= 16 ? at.substring(11, 16) : "--:--";
            LinearLayout tile = new LinearLayout(this);
            tile.setGravity(Gravity.CENTER);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setPadding(dp(1), dp(compact ? 0 : 2), dp(1), dp(compact ? 0 : 2));
            tile.setBackground(round(i == 0 ? 0xFF244363 : 0xFF222B36, 9));
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(compact ? 47 : 52), -2);
            if (i > 0) hp.leftMargin = dp(4);
            hourRow.addView(tile, hp);
            TextView hourView = text(i == 0 ? "现在" : hour, compact ? 9 : 10, WHITE, true);
            hourView.setGravity(Gravity.CENTER);
            tile.addView(hourView);
            TextView icon = text(emoji(hourlyCodes.optInt(j, 0), true), compact ? 16 : 20, WHITE, false);
            icon.setGravity(Gravity.CENTER);
            tile.addView(icon);
            TextView degrees = text(roundTemperature(temperatures.optDouble(j, Double.NaN)) + "°", compact ? 13 : 15, WHITE, true);
            degrees.setGravity(Gravity.CENTER);
            tile.addView(degrees);
            TextView rain = text("☂" + whole(chances.optDouble(j, Double.NaN)) + "%", compact ? 8 : 9, BLUE, false);
            rain.setGravity(Gravity.CENTER);
            tile.addView(rain);
            tile.setContentDescription(hour + " "
                    + weatherName(hourlyCodes.optInt(j, 0)) + " "
                    + roundTemperature(temperatures.optDouble(j, Double.NaN)) + "度，降雨概率 "
                    + whole(chances.optDouble(j, Double.NaN)) + "%");
        }

        JSONObject daily = response.getJSONObject("daily");
        JSONArray dates = daily.getJSONArray("time");
        JSONArray high = daily.getJSONArray("temperature_2m_max");
        JSONArray low = daily.getJSONArray("temperature_2m_min");
        JSONArray dayCodes = daily.getJSONArray("weather_code");
        JSONArray precip = daily.getJSONArray("precipitation_probability_max");
        daysList.removeAllViews();
        for (int i = 0; i < Math.min(7, dates.length()); i++) {
            String date = dates.optString(i, "");
            int dayCode = dayCodes.optInt(i, 0);
            LinearLayout tile = new LinearLayout(this);
            tile.setGravity(Gravity.CENTER);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setPadding(dp(1), dp(compact ? 0 : 2), dp(1), dp(compact ? 0 : 2));
            tile.setBackground(round(i == 0 ? 0xFF244363 : 0xFF222B36, 9));
            LinearLayout.LayoutParams cardP = new LinearLayout.LayoutParams(dp(compact ? 55 : 62), -2);
            if (i > 0) cardP.leftMargin = dp(4);
            daysList.addView(tile, cardP);
            String dayLabel = i == 0 ? "今天" : date.length() >= 10 ? date.substring(5).replace('-', '/') : shortDay(date);
            TextView day = text(dayLabel, compact ? 9 : 10, WHITE, true);
            day.setGravity(Gravity.CENTER);
            tile.addView(day);
            TextView symbol = text(emoji(dayCode, true), compact ? 16 : 20, WHITE, false);
            symbol.setGravity(Gravity.CENTER);
            tile.addView(symbol);
            TextView temperaturesView = text(roundTemperature(high.optDouble(i, Double.NaN))
                    + "°/" + roundTemperature(low.optDouble(i, Double.NaN)) + "°", compact ? 10 : 12, WHITE, true);
            temperaturesView.setGravity(Gravity.CENTER);
            temperaturesView.setSingleLine(true);
            tile.addView(temperaturesView);
            TextView rain = text("☂" + whole(precip.optDouble(i, Double.NaN)) + "%", compact ? 8 : 9, BLUE, false);
            rain.setGravity(Gravity.CENTER);
            tile.addView(rain);
            tile.setContentDescription(dayLabel + " " + weatherName(dayCode) + "，最高 "
                    + roundTemperature(high.optDouble(i, Double.NaN)) + "度，最低 "
                    + roundTemperature(low.optDouble(i, Double.NaN)) + "度，降雨概率 "
                    + whole(precip.optDouble(i, Double.NaN)) + "%");
        }
    }

    private void locateMe() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION }, REQUEST_LOCATION);
            return;
        }
        if (awaitingLocation) { toast("正在定位，请稍候"); return; }
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) { toast("无法使用定位服务"); return; }
        String provider = null;
        try {
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                provider = LocationManager.NETWORK_PROVIDER;
            } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                provider = LocationManager.GPS_PROVIDER;
            }
        } catch (Exception ignored) { }
        if (provider == null) { toast("请先开启手表定位服务"); return; }
        final String selectedProvider = provider;
        try {
            statusView.setText("正在获取手表位置…");
            Location last = locationManager.getLastKnownLocation(selectedProvider);
            if (last != null && System.currentTimeMillis() - last.getTime() < 20 * 60 * 1000L) {
                useLocation(last);
                return;
            }
            awaitingLocation = true;
            locationListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (!awaitingLocation) return;
                    awaitingLocation = false;
                    locationManager.removeUpdates(this);
                    locationListener = null;
                    useLocation(location);
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override public void onProviderEnabled(String provider) { }
                @Override public void onProviderDisabled(String provider) { }
            };
            LocationListener activeListener = locationListener;
            locationManager.requestSingleUpdate(selectedProvider, activeListener, Looper.getMainLooper());
            main.postDelayed(() -> {
                if (!awaitingLocation || locationListener != activeListener) return;
                awaitingLocation = false;
                try { locationManager.removeUpdates(activeListener); } catch (Exception ignored) { }
                locationListener = null;
                if (last != null) useLocation(last);
                else { statusView.setText("定位超时，请尝试搜索城市"); toast("定位超时，可手动搜索城市"); }
            }, 15000);
        } catch (SecurityException se) {
            awaitingLocation = false;
            toast("定位权限不足，请检查手表设置");
        } catch (Exception e) {
            awaitingLocation = false;
            toast("定位失败，请使用城市搜索");
        }
    }

    private void useLocation(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        city = "我的位置";
        cityView.setText(city);
        prefs.edit().putLong("lat", Double.doubleToRawLongBits(latitude))
                .putLong("lon", Double.doubleToRawLongBits(longitude))
                .putString("city", city).remove("cache").remove("cached_at").apply();
        clearCurrentWeather();
        showSkeleton();
        loadWeather();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) locateMe();
            else toast("没有定位权限，可通过城市搜索查看天气");
        }
    }

    private String httpGet(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(12000);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "CloudSkyWeather/1.0 (Android; Wear OS; Open-Meteo client)");
        try {
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new Exception("HTTP " + status);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder builder = new StringBuilder();
            String line;
            try {
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                    if (builder.length() > 1500000) throw new Exception("Response too large");
                }
            } finally { reader.close(); }
            if (status < 200 || status >= 300) throw new Exception("HTTP " + status + ": " + builder);
            return builder.toString();
        } finally { connection.disconnect(); }
    }

    private void ui(Runnable action) {
        main.post(() -> { if (!destroyed && !isFinishing()) action.run(); });
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable heroBackground(boolean day, int code) {
        int[] colors;
        if (!day) colors = new int[]{0xFF0F1826, 0xFF111C2B};
        else if (code >= 51 && code <= 82) colors = new int[]{0xFF152331, 0xFF10202C};
        else colors = new int[]{0xFF12263C, 0xFF101D2D};
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(25));
        return d;
    }

    private TextView actionChip(String label) {
        TextView t = text(label, 28, WHITE, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(0xFF263348, 14));
        return t;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(float size) { return (int) (size * getResources().getDisplayMetrics().density + 0.5f); }

    private String roundTemperature(double v) { return Double.isNaN(v) ? "--" : String.format(Locale.CHINA, "%.0f", v); }
    private String whole(double v) { return Double.isNaN(v) ? "--" : String.format(Locale.CHINA, "%.0f", v); }
    private String oneDecimal(double v) { return Double.isNaN(v) ? "--" : String.format(Locale.CHINA, "%.1f", v); }
    private String displayTime(String iso) { return iso.length() >= 16 ? iso.substring(0, 10) + " " + iso.substring(11, 16) : "--"; }

    private String shortDay(String raw) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(raw);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(d);
            String[] days = {"", "周日", "周一", "周二", "周三", "周四", "周五", "周六"};
            return days[calendar.get(Calendar.DAY_OF_WEEK)];
        } catch (Exception ignored) { return raw; }
    }

    private String weatherName(int code) {
        if (code == 0) return "晴朗";
        if (code == 1) return "大致晴朗";
        if (code == 2) return "局部多云";
        if (code == 3) return "阴天";
        if (code == 45 || code == 48) return "有雾";
        if (code >= 51 && code <= 57) return "毛毛雨";
        if (code == 61 || code == 80) return "小雨";
        if (code == 63 || code == 81) return "中雨";
        if (code == 65 || code == 82) return "大雨";
        if (code == 66 || code == 67) return "冻雨";
        if (code >= 71 && code <= 77) return "降雪";
        if (code >= 85 && code <= 86) return "阵雪";
        if (code == 95) return "雷雨";
        if (code == 96 || code == 99) return "雷暴冰雹";
        return "天气变化";
    }

    private String emoji(int code, boolean day) {
        if (code == 0) return day ? "☀️" : "🌙";
        if (code == 1 || code == 2) return day ? "🌤️" : "🌙";
        if (code == 3) return "☁️";
        if (code == 45 || code == 48) return "🌫️";
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "🌧️";
        if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return "🌨️";
        if (code >= 95) return "⛈️";
        return "🌥️";
    }

    @Override protected void onDestroy() {
        destroyed = true;
        requestSequence++;
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        }
        io.shutdownNow();
        super.onDestroy();
    }
}
